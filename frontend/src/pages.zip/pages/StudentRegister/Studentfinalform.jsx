import React, { useContext } from 'react'
import { Typography, Stepper, StepLabel, Step } from '@mui/material'
import Generaldetails from './Generaldetails'
import Familydetails from './Familydetails'
import Educationdetails from './Educationdetails'
import { multiStepContext } from '../../StepContext'



const Studentfinalform = () => {

  const {currentStep} = useContext(multiStepContext)
  function showStep(step) {
    switch (step) {
      case 1:
        return <Generaldetails />

      case 2:
        return <Familydetails />

      case 3:
        return <Educationdetails />


    }
  }

  return (
    <>

    <div>
      
     
        <div className="center-stepper" style={{alignContent:'center',marginTop:'50px',marginBottom:'100px',color:"green"}}>
          <Stepper style={{  justifyContent: "center", alignItems: "center"}} activeStep={currentStep-1} orientation='horizontal'>
            <Step>
              <StepLabel>

              </StepLabel>
            </Step>
            <Step>
              <StepLabel>

              </StepLabel>
            </Step>


            <Step>
              <StepLabel>

              </StepLabel>
            </Step>

          </Stepper>
        </div>
        {/* <Generaldetails/>
        <br></br>
        <Familydetails/>
        <br></br>
        <Educationdetails/> */}
        {showStep(currentStep)}

    </div>
    </>

  )
}

export default Studentfinalform;
