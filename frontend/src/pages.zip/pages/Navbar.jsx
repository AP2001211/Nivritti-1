import React, { useState } from 'react';
import {
  ListItem,
  ListItemIcon,
  ListItemButton,
  ListItemText,
  Box,
  Drawer,
  Modal,
  Button,
} from '@mui/material';
import Logo from '../assets/nivritti_logo-removebg-preview.png';
import {Link} from 'react-router-dom';
import Studentfinalform from './StudentRegister/Studentfinalform';

const Navbar = () => {
  const [modalOpen, setModalOpen] = useState(false);

  const handleModalOpen = () => {
    setModalOpen(true);
  };

  const handleModalClose = () => {
    setModalOpen(false);
  };

  return (
    <nav>
      <div className='nav-logo-container'>
        <img src={Logo} alt="" style={{width:"20%", height:"auto"}}/>
      </div>
      <div className='navbar-links-container' style={{ display: 'flex' }}>
        <button className='primary-button' style={{ display: 'inline-block',marginRight: '10px' }} onClick={handleModalOpen}>
          Student Registration
        </button>
        <Link to="/login">
          <button className='secondary-button' style={{ display: 'inline-block',marginRight: '10px' }}>
            Log in
          </button>
        </Link>
      </div>
      <Modal open={modalOpen} onClose={handleModalClose} style={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <Box sx={{ 
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          width: '50%',
          bgcolor: 'background.paper',
          boxShadow: 24,
          p: 4,
        }}>
          <h2 style={{marginBottom:"10px"}}>Read these guidelines carefully</h2>
          <ol>
            <li>Enter your personal information.</li>
            <li>Choose your courses and payment plan.</li>
            <li>Review and confirm your registration details.</li>
            <li>Submit your registration and payment.</li>
            <li>Check your email for confirmation and further instructions.</li>
            <li>Contact us if you have any questions or issues.</li>
          </ol>
          <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: '24px'}}>
            <button className='primary-button' onClick={handleModalClose}>close</button>
            <Link to='register-student'>
            <button className='secondary-button' style={{marginLeft:"12px"}}>proceed with registration</button>
            </Link>
          </div>
        </Box>
      </Modal>
    </nav>
  );
};

export default Navbar;
