import React from 'react';
// import './Footer.css';
import logo from '../assets/nivritti_logo-removebg-preview.png';
import { FaFacebookF, FaTwitter, FaInstagram } from 'react-icons/fa';

const Footer = () => {
  return (
   <div className='footer-wrapper'>
    <div className='footer-section-one'>
        <div className='footer-logo-container'>
            <img src={logo} alt=''/>
        </div>
        <div className='footer-icons'>
            <FaFacebookF/>
            <FaInstagram/>
            <FaTwitter/>
        </div>
    </div>
    <div className='footer-section-two'>
        <div className='footer-section-columns'>
            <span>Help</span>
            <span>India Now Foundation</span>
        </div>
        <div className='footer-section-columns'>
            <span>9937383</span>
            <span>anushkaj@gmail.com</span>
        </div>
        <div className='footer-section-columns'>

        </div>


    </div>

   </div>
  );
};

export default Footer;
