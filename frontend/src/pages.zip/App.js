import './App.css';
import Dashboard from './pages/Dashboard';
import { BrowserRouter, Route, Routes} from 'react-router-dom';
import Homepage from './pages/Homepage'; 
import Login from './pages/Login';
import InterviewerDashboard from './pages/InterviewerDashboard';
import StudentFinalForm from './pages/StudentRegister/Studentfinalform'



function App() {
  return (
    
    <div className="App">
      
      <BrowserRouter>
      <Routes>
      <Route exact path='/' element={<Homepage/>}/>
      <Route path="/dashboard" element={<Dashboard/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/interview' element={<InterviewerDashboard/>}/>
      <Route path='/student-register' element={<StudentFinalForm/>}/>
      </Routes>
      </BrowserRouter>
      
    </div>
   
   
  );
}

export default App;
